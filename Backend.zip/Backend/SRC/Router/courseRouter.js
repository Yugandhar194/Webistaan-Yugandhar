import { Router } from "express";
import { deleteapp, getapp, saveapp, updateapp } from "../Controller/courseController.js";


const courseRouter = Router();

courseRouter.post("/save",saveapp);
courseRouter.get("/display",getapp);
courseRouter.put("/update/:id",updateapp);
courseRouter.delete("/delete/:id", deleteapp);

export default courseRouter; 