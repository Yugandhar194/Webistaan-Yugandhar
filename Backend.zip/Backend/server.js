import express, { Router } from 'express';
import cors from 'cors';
import { establishConnection } from './SRC/Config/dbconfig.js';
import courseRouter from './SRC/Router/courseRouter.js';

const app = express();
app.use(cors());
const port = 5555;

// Use express.json() middleware to parse JSON payloads
app.use(express.json());

// GET route for the root path    
app.get('/', (req, res) => {
  res.send('Hello from Express!');
});

app.use('/course',courseRouter);

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);  
  establishConnection();
});
